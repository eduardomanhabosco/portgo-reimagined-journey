#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
int main() {
      system("chcp 65001 > nul"); 
    setlocale(LC_ALL, ".UTF8");
    float a, b;
    printf("Digite dois n�meros: ");
    scanf("%f %f", &a, &b);
    printf("Soma: %.2f\n", a + b);
    printf("Subtra��o: %.2f\n", a - b);
    printf("Multiplica��o: %.2f\n", a * b);
    if (b != 0)
        printf("Divis�o: %.2f\n", a / b);
    else
        printf("Divis�o por zero n�o � permitida.\n");
    return 0;
}